//
//  CategoriesListViewModel.swift
//  Lifestyle
//
//  Created by SHANKAR AWARE on 31/10/19.
//  Copyright © 2019 Shankar Aware. All rights reserved.
//

import Foundation

struct CategoriesListViewModel {
    
}
